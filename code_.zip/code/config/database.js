var DataBase={
    host:'localhost',
    database:'node',
    user:'vikas1',
    password:'TOOR'

};
module.exports=DataBase;
