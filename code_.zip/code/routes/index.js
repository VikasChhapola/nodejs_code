var express = require('express');
var router = express.Router();
var DataBase = require('../config/database.js');
var mysql = require('mysql');
var con = mysql.createConnection(DataBase);
/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('login');
});

router.post('/userValid', function(req, res, next) {
  console.log(req.body)
  data=req.body;
  username=data["uname"]; //xss //SQL
  password=data["psw"]
  con.connect(function(err){
  	sql ="select * from users where USER_NAME=\""+username+"\" and password=\""+password+"\"";
    con.query(sql,function(err,result){
  		if (err) throw err;
  		 if (result.length > 0) {
				console.log(result)
				final=[]
				// res.send(result)
					for (let index = 0; index < result.length; index++) {
						temp=[]
						temp.push(result[index]["firstname"])
						temp.push(result[index]["lastname"])
						temp.push(result[index]["occupation"])
						final.push(temp)
					}
					res.render('users',{ final})
			 }

  		 else
  		 {
  			res.render('login');
  		 }
  	})
  })
  // res.send("Page Working")
});

module.exports = router;
